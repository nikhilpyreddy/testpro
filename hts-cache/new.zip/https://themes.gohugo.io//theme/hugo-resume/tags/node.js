<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Eddie Webb | node.js</title>
  <meta property="og:title" content="Eddie Webb | node.js" />
  <meta property="og:image" content="https://themes.gohugo.io/theme/hugo-resume/img/TechChat.png" />
  <meta name="description" content="">
  <meta property="og:description" content="" />
  <meta name="author" content="Eddie Webb">
  
  <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css"></noscript>
  
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:100,200,300,400,500,600,700,800,900&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:100,200,300,400,500,600,700,800,900&display=swap"></noscript>
  <link rel="preload" href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
      <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap"></noscript>
  <link rel="preload" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css"></noscript>
  <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/devicons/1.8.0/css/devicons.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/devicons/1.8.0/css/devicons.min.css"></noscript>
  <link rel="preload" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css"></noscript>
  
  <link rel="preload" href="https://themes.gohugo.io/theme/hugo-resume/css/resume.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://themes.gohugo.io/theme/hugo-resume/css/resume.css"></noscript>
  <link rel="preload" href="https://themes.gohugo.io/theme/hugo-resume/css/tweaks.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://themes.gohugo.io/theme/hugo-resume/css/tweaks.css"></noscript>
  <link rel="preload" href="https://themes.gohugo.io/theme/hugo-resume/css/resume-override.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://themes.gohugo.io/theme/hugo-resume/css/resume-override.css"></noscript>
  <meta name="generator" content="Hugo 0.70.0" />
  
   
  
</head>
<body id="page-top">
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
  <a class="navbar-brand js-scroll-trigger" href="#page-top">
    <span class="d-block d-lg-none">Eddie Webb</span>
    <span class="d-none d-lg-block">
      <img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="https://themes.gohugo.io//theme/hugo-resume/img/TechChat.png" alt="">
    </span>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link js-scroll-trigger" href="https://themes.gohugo.io//theme/hugo-resume/#about">About</a>
      </li>
      
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="https://themes.gohugo.io//theme/hugo-resume/#skills">Skills</a>
          </li>
      
      
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="https://themes.gohugo.io//theme/hugo-resume/#projects">Projects</a>
          </li>
      
      
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="https://themes.gohugo.io//theme/hugo-resume/#open">Open Source</a>
          </li>
      
      
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="https://themes.gohugo.io//theme/hugo-resume/#Publications">Publications</a>
          </li>
      
      
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="https://themes.gohugo.io//theme/hugo-resume/#experience">Experience</a>
          </li>
      
      
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="https://themes.gohugo.io//theme/hugo-resume/#education">Education</a>
          </li>
      
      
    </ul>
  </div>
</nav>

  <div class="container-fluid p-0">
    

<section class="resume-section p-3 p-lg-5 d-flex d-column">
  <div class="my-auto">

  Content tagged with  <span class="tag">node.js</span>
    <ul>
      
          <li>
             <a href="https://themes.gohugo.io//theme/hugo-resume/projects/contributions/shields-docker/">Added Docker Build Status Badge to shields.io</a>
         </li>
      
    </ul>
  </div>
</section>


    <span style="color: #999999; font-size: 60%;">Nifty <a href="https://codepen.io/wbeeftink/pen/dIaDH">tech tag lists</a> from <a class="pen-owner-link" href="https://codepen.io/wbeeftink">Wouter Beeftink</a> </span>
    
  </div>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script async src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>

  
  <script async src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
  
  <script async src="https://themes.gohugo.io//theme/hugo-resume/js/resume.js"></script>
  <script async src="https://www.googletagmanager.com/gtag/js?id=XX-123446-01"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'XX-123446-01');
  </script>
  

  
</body>
</html>
